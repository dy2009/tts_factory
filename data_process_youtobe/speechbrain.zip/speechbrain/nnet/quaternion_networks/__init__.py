"""Package containing quaternion neural networks
"""
